package com.wind.server.entity.list;

public class ListPack {
    ListResult result ;

    public ListResult getResult() {
        return result;
    }

    public void setResult(ListResult result) {
        this.result = result;
    }
}
