package com.wind.server.entity.search;

import java.util.List;

public class Result {
    List<Songs> songs;

    public List<Songs> getSongs() {
        return songs;
    }

    public void setSongs(List<Songs> songs) {
        this.songs = songs;
    }
}
